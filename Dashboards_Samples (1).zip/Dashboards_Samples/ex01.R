library(shinydashboard)
library(shiny)

ui <- dashboardPage(
  dashboardHeader(title = "Quick Example"),
  dashboardSidebar(textInput("text", "Text")),
  dashboardBody(
    valueBox(100, "Basic example"),
    tableOutput("mtcarsData")
  )
)

server <- function(input, output) {
  output$mtcarsData <- renderTable(head(mtcars))
}

shinyApp(ui, server)

###

